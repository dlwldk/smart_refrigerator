package com.example.myapplication03;

import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Add01 extends AppCompatActivity {
    Toolbar myToolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add01);

        Toolbar myToolbar = (Toolbar) findViewById(R.id.my_toolbar01);
        setSupportActionBar(myToolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_menu_white_24dp);

        getSupportActionBar().setTitle("MY 냉장고");
    }

    public void onClickB04(View v){
        Intent intentB04 = new Intent(getApplicationContext(), Add02.class);
        startActivity(intentB04);
    }

    public void onClickB09(View v){
        Intent intentB09 = new Intent(getApplicationContext(), Camera00.class);
        startActivity(intentB09);
    }
}
