package com.example.myapplication03;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class Check01 extends AppCompatActivity {

    Toolbar myToolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check01);

        Toolbar myToolbar = (Toolbar) findViewById(R.id.my_toolbar02);
        setSupportActionBar(myToolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_menu_white_24dp);

        getSupportActionBar().setTitle("MY 냉장고");
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        //return super.onCreateOptionsMenu(menu);
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.barmenu02, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent intentB03 = new Intent(getApplicationContext(), Add01.class);
        // Handle presses on the action bar items
        switch (item.getItemId()) {
            case R.id.menu_add:
                startActivity(intentB03);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
